package main;

import Utilidades.FuncoesUteis;

public class main {

	public static void main(String[] args) {
		
		//Instanciando
		FuncoesUteis funcoes = new FuncoesUteis();
        
		
		//Método soma
		int resultadoSoma = funcoes.soma(3, 9);
		System.out.println("Resultado :" + resultadoSoma);
		
		
		//Método triângulo
		
		System.out.println("Triângulo de altura 9 :");
		funcoes.triangulo(9);
		
		
		//Método de printArquivo
		
		System.out.println("Conteudo arquivo:");
		funcoes.printArquivo("caminho/do/arquivo.txt");
	}

}
