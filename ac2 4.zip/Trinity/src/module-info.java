/**
 * 
 */
/**
 * 
 */
module Trinity {
}