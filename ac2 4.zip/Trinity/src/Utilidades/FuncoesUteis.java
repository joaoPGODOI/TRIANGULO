package Utilidades;

import java.io.BufferedReader;
import java.io.FileReader;


public class FuncoesUteis {

	//Metodo de soma dos parâmetros
	
	public int soma(int a, int b) {
		return a + b;
	}
  
	
	//Método para exibir altura do triângulo
	
	public void triangulo(int altura) {
		for(int i = 1; i <= altura;i++) {
			for(int j = 1; j <= altura; j++) {
			  System.out.println("x");
			}
			System.out.println();        //Exibição "i"
		}
	}
	
	//Método para ler o arquivo de texo e imprimir 
	
	public void printArquivo(String arquivo) {
		try (BufferedReader br = new BufferedReader(new FileReader(arquivo))){
			String linha;
			while((linha = br.readLine()) != null) {
				System.out.println(linha);
			}
		}
	}
}
